module pl.ksr.pon.cla {
    requires static lombok;
    requires pl.ksr.pon.ext;
    exports pl.ksr.pon.cla;
}