module pl.ksr.pon.dao {
    requires pl.ksr.pon.ext;
    exports pl.ksr.pon.dao;
    requires org.apache.commons.lang3;
    requires org.jsoup;
    requires snowball.stemmer;
}