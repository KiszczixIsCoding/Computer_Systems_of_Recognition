module pl.ksr.pon.ext {
    requires static lombok;
    requires org.apache.commons.lang3;
    exports pl.ksr.pon.ext;
    exports pl.ksr.pon.ext.fea;
}