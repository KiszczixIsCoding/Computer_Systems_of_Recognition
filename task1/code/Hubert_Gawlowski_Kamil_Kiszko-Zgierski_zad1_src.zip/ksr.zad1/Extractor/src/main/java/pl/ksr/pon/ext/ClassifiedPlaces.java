package pl.ksr.pon.ext;

public enum ClassifiedPlaces {
    west_germany,
    japan,
    france,
    uk,
    usa,
    canada
}
