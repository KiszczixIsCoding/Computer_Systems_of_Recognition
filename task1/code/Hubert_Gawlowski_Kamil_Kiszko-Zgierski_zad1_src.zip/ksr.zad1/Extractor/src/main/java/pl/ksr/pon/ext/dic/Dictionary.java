package pl.ksr.pon.ext.dic;

import java.util.List;

public interface Dictionary {
    List<String> getDictionary();
}
