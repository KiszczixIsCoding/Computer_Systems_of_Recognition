package pl.ksr.pon.gui;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class Benchmark {
    private String name;
    private Double value;
}
